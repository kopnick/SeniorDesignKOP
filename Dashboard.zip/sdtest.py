import pandas as pd
from sqlalchemy import create_engine
import os
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings("ignore", category=FutureWarning, module="pandas")
pd.options.mode.chained_assignment = None


# --- CONFIGURATION ---
# Replace with your 'Public Connection String' from Railway
# It looks like: postgresql://postgres:password@host:port/railway
DB_URL = "postgresql://postgres:QbcDZnDSLdphWUiKWtMnpTuoZgYvGUpm@monorail.proxy.rlwy.net:10094/railway"

# The name of the Excel file you want to create/update
# The SQL query to pull the specific data you need
now = datetime.now()

day = now.day
month = now.month
year = now.year

db_name = f'events_p_{year}{month if month > 9 else '0'+str(month)}{day if day > 9 else '0'+str(day)}'



current_date = datetime.now().strftime('%Y-%m-%d')
filename = f"data_{current_date}.xlsx"
guifilename = f"gui_{current_date}.xlsx"



def refresh_data():

    try:
        data = pd.read_excel(filename, index_col = 0)
        last_id = data['id'].max()
        if type(last_id) != int:
            last_id = 0
    except:
        data = pd.DataFrame()
        last_id = 0
        

    try:
        engine = create_engine(DB_URL)
    
        SQL_QUERY = f"SELECT * FROM {db_name} WHERE id > %(last_id)s;"

        # 2. Define the parameters in a dictionary
        query_params = {'last_id': last_id}

        # 3. Pass the params to read_sql
        df = pd.read_sql(SQL_QUERY, engine, params=query_params)
        
    except:
        df = pd.DataFrame()
        print('error')
    print(len(df), len(data))
    

    df = pd.concat([data, df], ignore_index=True)
    try:
        df['timestamp'] = pd.to_datetime(df['timestamp'])
    except:
        print('No timestamp column found, might be an empty df? This will error out in a second.')
    try:
        df = df.sort_values('id')
    except:
        df = df

    try:
        wrap_df = df[df['sensor_name'] == 'Dry Contact - Wrap']  ### Isolating wrap sensor data
        air_df = df[df['sensor_name'] == 'Dry Contact - Air Cooled'] ### Isolating air cooled freezer data
        water_df = df[df['sensor_name'] == 'Dry Contact - Water Cooled'] ### Isolating hydraulic cooled freezer data
        freezer_container_df = df[df['sensor_name'] == 'Freezer Container'] ### Isolating freezer container
        freezer_main_df = df[df['sensor_name'] == 'Freezer Main'] ### Isolating freezer main
        fridge_blend_df = df[df['sensor_name'] == 'Fridge Blend'] ### Isolating fridge blend
        fridge_hall_df = df[df['sensor_name'] == 'Fridge Hall'] ### Isolating fridge hall
    except:
        print('No sensor_name column found, might be pulling from an empty df')






    #Finding Number wrapped
    #print(len(wrap_df))
    try:
        time_diff = abs(wrap_df['timestamp'].diff())

        #print(wrap_df)

        mask = (
                (wrap_df['state'] == 'Open') & 
                (wrap_df['state'].shift(1) == 'Closed') & 
                (time_diff <= pd.Timedelta(seconds=61))
            )
        wrap_df = wrap_df[mask]
    except:
        wrap_df = pd.DataFrame()
        print('wrap_df dataframe errored on creation ---- replacing with an empty df')
        #print(f"Found {count * 2} occurrences of 'open -> closed' within 60 seconds.")

    current_wrapped = len(wrap_df) * 2



    

    ####Finding 30 most recent air pulls:
    mask = (
            (air_df['state'] == 'Open') & 
            (air_df['state'].shift(1) == 'Closed')
        )
    air_df = air_df[mask]
    if len(air_df) < 30:
        recent_air = air_df
        now = pd.Timestamp.now()
        recent_air['time_diff'] = now - recent_air['timestamp']
        recent_air = recent_air['time_diff']
    else:
        recent_air = air_df.tail(30)
        now = pd.Timestamp.now()
        recent_air['time_diff'] = now - recent_air['timestamp']
        recent_air = recent_air['time_diff']


    try:
        air_minutes = [td.total_seconds() / 60 for td in list(recent_air)]

        l_w = len(air_minutes)
        if l_w < 30:
            new = [0 for i in range (30-l_w)]
            air_minutes = new + air_minutes
    except:
        air_minutes = [0 for i in range(30)]


    ####Finding 30 most recent water pulls:
    mask = (
            (water_df['state'] == 'Open') & 
            (water_df['state'].shift(1) == 'Closed')
        )
    water_df = water_df[mask]
    #print(water_df)

    if len(water_df) < 30:
        recent_water = water_df
        now = pd.Timestamp.now()
        recent_water['time_diff'] = now - recent_water['timestamp']
        recent_water = recent_water['time_diff']
    else:
        recent_water = water_df.tail(30)
        now = pd.Timestamp.now()
        recent_water['time_diff'] = now - recent_water['timestamp']
        recent_water = recent_water['time_diff']

    try:
        water_minutes = [td.total_seconds() / 60 for td in list(recent_water)]

        l_w = len(water_minutes)
        if l_w < 30:
            new = [0 for i in range (30-l_w)]
            water_minutes = new + water_minutes
    except:
        water_minutes = [0 for i in range(30)]

    ###Finding Num Pulled
    total_air_pulled = 28 * len(air_df)
    total_water_pulled = 28 * len(water_df)
    total_pull = total_air_pulled + total_water_pulled


    ###Finding Pull Rate
    timenow = pd.Timestamp.now()

    try:
        first_water_pull = water_df['timestamp'].iloc[0]
    except:
        first_water_pull = timenow
    try:
        first_air_pull = air_df['timestamp'].iloc[0]
    except:
        first_air_pull = timenow

    try:
        first_wrap = wrap_df['timestamp'].iloc[0]
    except:
        first_wrap = timenow
    #print(first_air_pull, first_water_pull)

    ###Finding Water rate
    try:
        water_rate = len(water_df)/(timenow - first_water_pull).total_seconds() * 60
    except:
        water_rate = 0

    ###Finding Air rate
    try:
        air_rate = len(air_df)/(timenow - first_air_pull).total_seconds() * 60 
        air_avg_min = 1 / air_rate
    except:
        air_rate = 0

    ###Finding Wrap rate
    try:
        wrap_rate = len(wrap_df) / (timenow - first_wrap).total_seconds() * 60 
        print(len(wrap_df))
        print(wrap_df)
    except:
        wrap_rate = 0


    #Last 10 pull rate
    try:
        last_10_pull_air = air_df.tail(10)
        dif = timenow - last_10_pull_air['timestamp'].iloc[0]
        last_10_air_rate = abs(dif.total_seconds()) / len(last_10_pull_air)

    except:
        last_10_air_rate = 0


    try:
        last_10_pull_water = water_df.tail(10)
        dif = last_10_pull_water['timestamp'].iloc[0] - timenow
        last_10_pull_water_rate = abs(dif.total_seconds()) / len(last_10_pull_water)
    except:
        last_10_water_rate = 0


    #Last 30 min wrap rate
    try:
        last_30_min_wrap = wrap_df[np.where(((timenow - wrap_df['timestamp']).total_seconds() * 60)<= 30, True, False)]
        last_30_wrap_rate = len(last_30_min_wrap) / 30
    except:
        last_30_wrap_rate = 0


    freezer_container_df = df[df['sensor_name'] == 'Freezer Container'] ### Isolating freezer container
    freezer_main_df = df[df['sensor_name'] == 'Freezer Main'] ### Isolating freezer main
    fridge_blend_df = df[df['sensor_name'] == 'Fridge Blend'] ### Isolating fridge blend
    fridge_hall_df = df[df['sensor_name'] == 'Fridge Hall'] ### Isolating fridge hall
    ###Freezer Temp tracking
    try:
        l_5_fc = freezer_container_df['state'].tail(1).tolist()
    except:
        l_5_fc = []

    #Freezer Main
    try:
        l_5_fm = freezer_main_df['state'].tail(1).tolist()
    except:
        l_5_fm = []

    #Fridge Blend
    try:
        l_5_fb = fridge_blend_df['state'].tail(1).tolist()
    except:
        l_5_fb = []

    #Fridge Hall
    try:
        l_5_fh = fridge_hall_df['state'].tail(1).tolist()
    except:
        l_5_fh = []


    #print(df)
    df.to_excel(filename)


    outputs = {'Total_Pulled' : total_pull, 'Total_Air_Pulled' : total_air_pulled, 
    'Total_Water_Pulled' : total_water_pulled, 'Total Wrapped' : current_wrapped,
    '30_min_wrap_rate' : last_30_wrap_rate, 'L10_air_rate' : last_10_air_rate,
    'L10_water_rate' : last_10_water_rate, 'total_wrap_rate' : wrap_rate,
    'total_air_rate' : air_rate, 'total_water_rate' : water_rate,
    '30_air_time' : air_minutes, '30_water_time' : water_minutes,
    'freezer_container' : l_5_fc, 'freezer_main' : l_5_fm,
    'fridge_blend' : l_5_fb, 'fridge_hall' : l_5_fh}

    outputs = pd.DataFrame.from_dict(outputs, orient='index')

    outputs.to_excel(guifilename)




if __name__ == "__main__":
    refresh_data()