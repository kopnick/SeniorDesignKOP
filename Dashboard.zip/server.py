"""
King of Pops — Dashboard Local Server
--------------------------------------
1. Put this file in the same folder as popsicle_dashboard.html and sdtest_updated.py
2. Run:  python server.py
3. Open: http://localhost:8000/popsicle_dashboard.html

The server automatically runs sdtest_updated.py every 30 seconds to keep
the dashboard data fresh. The browser will pick up changes on its next
auto-refresh cycle.
"""

import http.server
import socketserver
import os
import threading
import subprocess
import time

PORT         = 8000
REFRESH_SEC  = 15
SDTEST       = "sdtest.py"

os.chdir(os.path.dirname(os.path.abspath(__file__)))


def refresh_loop():
    while True:
        try:
            result = subprocess.run(
                ["python", SDTEST],
                capture_output=True, text=True, timeout=60
            )
            if result.stdout:
                print(f"  [sdtest] {result.stdout.strip()}")
            if result.returncode != 0 and result.stderr:
                print(f"  [sdtest ERROR] {result.stderr.strip()[:200]}")
        except Exception as e:
            print(f"  [sdtest ERROR] {e}")
        time.sleep(REFRESH_SEC)


# Run sdtest once immediately before the server starts
print()
print("  King of Pops Dashboard")
print("  ─────────────────────────────────────")
print("  Running initial data refresh...")
try:
    result = subprocess.run(["python", SDTEST], capture_output=True, text=True, timeout=60)
    if result.stdout:
        print(f"  [sdtest] {result.stdout.strip()}")
    print("  Initial refresh complete.")
except Exception as e:
    print(f"  [sdtest ERROR] {e}")

# Start background refresh thread
t = threading.Thread(target=refresh_loop, daemon=True)
t.start()

handler = http.server.SimpleHTTPRequestHandler

with socketserver.TCPServer(("", PORT), handler) as httpd:
    print()
    print(f"  Server running at http://localhost:{PORT}")
    print(f"  Open → http://localhost:{PORT}/popsicle_dashboard.html")
    print()
    print(f"  Data refreshes every {REFRESH_SEC}s via {SDTEST}")
    print(f"  To stop: press Ctrl+C")
    print()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n  Server stopped.")